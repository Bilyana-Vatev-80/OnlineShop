package onlineShop.models.products.components;

import onlineShop.models.products.Product;

public interface Component extends Product {

    int getGeneration();
}
